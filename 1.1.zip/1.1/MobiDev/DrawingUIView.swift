//
//  DrawingUIView.swift
//  MobiDev
//
//  Created by Cockerman on 23.04.2021.
//

import UIKit

class DrawingUIView: UIView {
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.setNeedsDisplay()
    }
    
    var drawing = ""
    
    @IBAction func changeDrawing(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex{
        case 0:
            drawing = "Graph"
            self.setNeedsDisplay()
        case 1:
            drawing = "Diagram"
            self.setNeedsDisplay()
        default:
            self.setNeedsDisplay()
            break
        }
    }
    
    override func draw(_ rect: CGRect) {
        if drawing == "Graph" || drawing == ""{
            
            let lineColor = UIColor.blue
            let axisColor = UIColor.black
            let graph = UIBezierPath()
            var x = -2*Double.pi
            var y = sin(x)
            let halfFrameWidth = Double(frame.width/2)
            let halfFrameHeight = Double(frame.height/2)
            let axes = UIBezierPath()
            
            //Axes
            axes.move(to: CGPoint(x: halfFrameWidth+15*x, y: halfFrameHeight))
            axes.addLine(to: CGPoint(x: halfFrameWidth-15*x, y: halfFrameHeight))
            axes.move(to: CGPoint(x: halfFrameWidth, y: halfFrameHeight+15*x))
            axes.addLine(to: CGPoint(x: halfFrameWidth, y: halfFrameHeight-15*x))
            axes.move(to: CGPoint(x: halfFrameWidth-5, y: halfFrameHeight-15))
            axes.addLine(to: CGPoint(x: halfFrameWidth+5, y: halfFrameHeight-15))
            axes.move(to: CGPoint(x: halfFrameWidth+15, y: halfFrameHeight-5))
            axes.addLine(to: CGPoint(x: halfFrameWidth+15, y: halfFrameHeight+5))
            axisColor.setStroke()
            axes.lineWidth = 3
            axes.stroke()
                      
            let startpoint = CGPoint(x:halfFrameWidth-15*x, y:halfFrameHeight+15*y)
            graph.move(to: startpoint)
                
            while x <= 2*Double.pi+0.1{
                graph.addLine(to: CGPoint(x: halfFrameWidth-15*x, y: 15*y+halfFrameHeight))
                x += Double.pi/16
                y = sin(x)
            }
            lineColor.setStroke()
            graph.lineWidth = 3
            graph.stroke()
            
        }else{
            let arc1 = UIBezierPath()
            let arc2 = UIBezierPath()
            let arc3 = UIBezierPath()
            let arc4 = UIBezierPath()
            let fullCircle = Double.pi * 2
            
            arc1.addArc(withCenter: CGPoint(x: frame.width/2, y: frame.height/2), radius: CGFloat(100), startAngle: CGFloat(0), endAngle: CGFloat(fullCircle/20), clockwise: true)
            UIColor.brown.setStroke()
            arc1.lineWidth = 50
            arc1.stroke()
            
            arc2.addArc(withCenter: CGPoint(x: frame.width/2, y: frame.height/2), radius: CGFloat(100), startAngle: CGFloat(fullCircle/20), endAngle: CGFloat(fullCircle/10), clockwise: true)
            UIColor.cyan.setStroke()
            arc2.lineWidth = 50
            arc2.stroke()
            
            arc3.addArc(withCenter: CGPoint(x: frame.width/2, y: frame.height/2), radius: CGFloat(100), startAngle: CGFloat(fullCircle/10), endAngle: CGFloat(fullCircle/5), clockwise: true)
            UIColor.orange.setStroke()
            arc3.lineWidth = 50
            arc3.stroke()
            
            arc4.addArc(withCenter: CGPoint(x: frame.width/2, y: frame.height/2), radius: CGFloat(100), startAngle: CGFloat(fullCircle/5), endAngle: CGFloat(fullCircle), clockwise: true)
            UIColor.blue.setStroke()
            arc4.lineWidth = 50
            arc4.stroke()
            
        }
    }
}

